using System;

public interface IDataModel
{
	
}

