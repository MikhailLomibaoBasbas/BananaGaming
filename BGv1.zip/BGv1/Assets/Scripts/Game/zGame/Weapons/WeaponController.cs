﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class WeaponController : MonoBehaviour {
	public Weapon.WeaponType type;
	private List<Projectile> projectiles;
	private Weapon _weapon;

	private bool _canAttack;
	private float _batRecoveryTime;

	void Awake () {
		_weapon = WeaponDataController.getInstance.weaponsMap[type.ToString()];
		InitProjectile();
		_canAttack = true;
	}

	private void InitProjectile () {
		Transform ammoContainerTrans = transform.FindChild("ammoContainer");
		projectiles = new List<Projectile>(
			ammoContainerTrans.GetComponentsInChildren<Projectile>(true)
			);
		foreach(Projectile pr in projectiles) {
			pr.SetValues(ammoContainerTrans, _weapon.projectileTime, _weapon.projectileDistance);
		}

	}


	void Update () {
		if(!_canAttack) {
			if(_batRecoveryTime < _weapon.baseAttackTime) {
				_batRecoveryTime += Time.deltaTime;
			} else {
				_batRecoveryTime = 0;
				_canAttack = true;
			}
		}
	}

	public void Attack () {
		if(_canAttack /*&& _weapon.currentAmmo > 0*/) {
			//Debug.LogError(projectiles.Count);
			foreach(Projectile pr in projectiles) {
				if(!pr.isActive) {
					pr.Show(transform.position.x > transform.parent.position.x);
					_canAttack = false;
					_batRecoveryTime = 0;
					//Debug.LogError(_weapon.currentAmmo);
					//_weapon.currentAmmo--;
						break;
				}
			}
		}
	}
}
