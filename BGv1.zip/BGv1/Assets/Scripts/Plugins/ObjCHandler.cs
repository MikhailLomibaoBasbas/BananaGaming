using System;
using System.Collections.Generic;

public struct ObjCResult {
	public bool success;
	public string message;
}

public class ObjCHandler {
	
	
}