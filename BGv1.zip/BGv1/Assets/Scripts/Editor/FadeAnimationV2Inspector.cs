﻿using UnityEngine;
using System.Collections;
using UnityEditor;
[CustomEditor(typeof(FadeAnimationV2))]
public class FadeAnimationV2Inspector : Editor {
	public override void OnInspectorGUI (){}	
}
