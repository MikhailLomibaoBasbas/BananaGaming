﻿using UnityEngine;
using System.Collections;
using UnityEditor;
[CustomEditor(typeof(SplineAnimation))]
public class SplineAnimationInspector : Editor {
	public override void OnInspectorGUI (){}	
}