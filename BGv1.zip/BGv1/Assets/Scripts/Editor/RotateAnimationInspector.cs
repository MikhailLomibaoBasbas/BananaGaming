﻿using UnityEngine;
using System.Collections;
using UnityEditor;
[CustomEditor(typeof(RotateAnimation))]
public class RotateAnimationInspector : Editor {
	public override void OnInspectorGUI (){}	
}