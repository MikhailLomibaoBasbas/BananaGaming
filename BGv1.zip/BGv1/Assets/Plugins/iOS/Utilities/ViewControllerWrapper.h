//
//  ViewControllerWrapper.h
//  Unity-iPhone
//
//  Created by Mikhail Lomibao Basbas on 4/12/13.
//
//

#import <UIKit/UIKit.h>

@interface WrapperView : UIView {}
@end

@interface ViewControllerWrapper : UIViewController {}

-(id) init;
@end
