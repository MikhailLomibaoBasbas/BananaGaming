﻿using UnityEngine;
using System.Collections;
using UnityEditor;
[CustomEditor(typeof(BezierCurveAnimation))]
public class BezierCurveAnimationInspector : Editor {
	public override void OnInspectorGUI (){}	
}
