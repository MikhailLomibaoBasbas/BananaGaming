﻿using UnityEngine;
using System.Collections;
using UnityEditor;
[CustomEditor(typeof(MoveAnimationV2))]
public class MoveAnimationV2Inspector : Editor {
	public override void OnInspectorGUI (){}	
}