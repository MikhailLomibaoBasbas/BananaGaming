Standard Template for Unity3D Games
===================================
KLab Cyscorpions - Studio 3
===================================

Goals:
* Create standard workflow for preparing and managing screens.
* Provide mobile plugins for commonly used libraries (SNS, IAP, GameCenter, etc...)
* Set folder structure and naming conventions
* Solve commonly encountered workflow issues
