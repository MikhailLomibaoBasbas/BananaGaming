﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Weapon {
	public enum WeaponType {
		Pistol, Shotgun, AK47
	}
	public string id;
	public string name;
	public float projectileTime;
	public float projectileDistance;
	public int damage;
	public float baseAttackTime;
	public int currentAmmo;
	public int maxAmmo;
	public WeaponType type;

	public Weapon (string mId, string mName, float time, float distance, int dmg, float bat, int cAmmo, int mAmmo, WeaponType mType){
		id = mId;
		name = mName;
		projectileTime = time;
		projectileDistance = distance;
		damage = dmg;
		baseAttackTime = bat;
		currentAmmo = cAmmo;
		maxAmmo = mAmmo;
		type = mType;
	}
}
