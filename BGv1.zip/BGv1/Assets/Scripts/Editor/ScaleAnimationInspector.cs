﻿using UnityEngine;
using System.Collections;
using UnityEditor;
[CustomEditor(typeof(ScaleAnimation))]
public class ScaleAnimationInspector : Editor {
	public override void OnInspectorGUI (){}	
}