﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class WeaponDataController {
	private static WeaponDataController _instance = null;
	public static WeaponDataController getInstance {
		get {
			if(_instance == null)
				_instance = new WeaponDataController();
			return _instance;
		}
	}

	public Dictionary<string, Weapon> weaponsMap;
	public WeaponDataController(){
		weaponsMap = new Dictionary<string, Weapon>();
		Weapon pistol = new Weapon("5nrjh6oi5i", "Pistol", 0.4f, 1000, 1, 0.5f, 0, 0, Weapon.WeaponType.Pistol);
		Weapon shotGun = new Weapon("ok0ck8z9sn", "ShotGun", 0.5f, 900, 5, 1.5f, 30, 30, Weapon.WeaponType.Shotgun);
		Weapon ak47 = new Weapon("5fogt8di5i", "AK47", 0.3f, 1200, 2, 0.05f, 200, 200, Weapon.WeaponType.AK47);

		weaponsMap.Add(pistol.name, pistol);
		weaponsMap.Add(shotGun.name, shotGun);
		weaponsMap.Add(ak47.name, ak47);
	}
}
